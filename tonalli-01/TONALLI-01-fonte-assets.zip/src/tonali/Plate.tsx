import {AbsoluteFill, Img, staticFile} from 'remotion'
import {garmentOutline} from './outline'

export function GarmentPlate() {
  return <AbsoluteFill>
    <div style={{position:'absolute',left:96,top:96,width:1280,height:1280,
      transform:'scale(1.2)',transformOrigin:'0 0',filter:'drop-shadow(10px 16px 19px #100d0a73)'}}>
      <Img src={staticFile('tonali/moletom.webp')} style={{
        width:1280,height:1280,display:'block',clipPath:`path('${garmentOutline}')`}}/>
    </div>
  </AbsoluteFill>
}

export function LockupPlate() {
  return <AbsoluteFill>
    <svg width="0" height="0" aria-hidden style={{position:'absolute'}}>
      <defs><filter id="tonali-crest-paper" colorInterpolationFilters="sRGB">
        <feColorMatrix in="SourceGraphic" result="ink" type="matrix"
          values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -2.5 -5.4 -.7 0 7.7"/>
        <feComposite in="SourceGraphic" in2="ink" operator="in"/>
      </filter></defs>
    </svg>
    <AbsoluteFill style={{filter:'url(#tonali-crest-paper)',overflow:'hidden'}}>
      <Img src={staticFile('tonali/simbolo.webp')} style={{
        position:'absolute',left:-266,top:-211,width:1280,height:1280}}/>
    </AbsoluteFill>
  </AbsoluteFill>
}
