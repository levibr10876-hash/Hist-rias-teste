import {Composition, registerRoot} from 'remotion'
import {LockupPlate, GarmentPlate} from './Plate'
registerRoot(()=><>
  <Composition id="TonaliGarmentPlate" component={GarmentPlate} width={1728} height={1728} fps={60} durationInFrames={1}/>
  <Composition id="TonaliLockupPlate" component={LockupPlate} width={758} height={828} fps={60} durationInFrames={1}/>
</>)
