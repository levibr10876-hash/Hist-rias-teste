"""Synthesize the original TONALLI score from its editorial anchors."""
from argparse import ArgumentParser
from array import array
import json
from math import exp, pi, sin, tanh
from pathlib import Path
from random import Random
import subprocess
import sys
from tempfile import TemporaryDirectory
import wave

root = Path(__file__).resolve().parents[1]
plan = json.loads((root / "src/tonali/score.json").read_text())
rate = 32000
duration = plan["duration"]
rng = Random(417)
samples = array("h")
tau = 2 * pi
beat = .648
bass_notes = (36.708, 36.708, 43.654, 32.703, 36.708, 36.708, 43.654, 29.135)
previous_noise = 0

def fade_in(time, start, end):
    p=max(0,min(1,(time-start)/(end-start)))
    return p*p*(3-2*p)

for i in range(rate * duration):
    t = i / rate
    bar_phase = t / beat
    beat_index = int(bar_phase)
    beat_time = (bar_phase-beat_index)*beat
    note = bass_notes[(beat_index//2) % len(bass_notes)]
    noise = rng.uniform(-1, 1)
    treble = (noise - previous_noise) * .55
    previous_noise = noise

    # The hats, clap and slides leave space around close-ups and the final lockup.
    drive = .72-.35*fade_in(t,6.96,7.25)*(1-fade_in(t,11.81,12.10))
    if t > 17.05:
        drive *= max(.14,1-(t-17.05)*.32)
    bass_env = min(1,beat_time*37)*exp(-beat_time*4.0)
    bass = (.25*sin(tau*note*beat_time)+.045*sin(tau*2*note*beat_time))*bass_env
    kick = .28*sin(tau*(44*beat_time + 1.27*(1-exp(-39*beat_time))))*exp(-beat_time*21)
    if beat_index%4 in (1,3):
        kick *= .13
    hat_time=(t+.032)%(beat/2)
    hats = treble*.061*exp(-hat_time*84)*min(1,hat_time*504)
    clap = 0
    if beat_index%4 in (1,3):
        clap = treble*.086*sum(exp(-(beat_time-offset)*56) for offset in (0,.015,.03)
                               if offset<=beat_time)
    pulse_time=t % (beat*2)
    chord = sum(sin(tau*f*pulse_time) for f in (146.83,174.61,220))*.028*exp(-pulse_time*3.6)
    chord *= min(1,pulse_time*47)
    middle=.014*sin(tau*(213*t+.20*sin(2.12*t)))

    accents = 0
    for at, kind in plan["cues"]:
        d=t-at
        if kind=="stamp":
            if -.30<=d<0 and at>1:
                accents += .053*treble*exp(d*15)
            if 0<=d<.43:
                accents += (.36*sin(tau*(47*d+1.79*(1-exp(-21*d))))+.095*treble)*exp(-d*14)
        elif kind=="metal" and -.17<=d<.43:
            if d<0:
                accents += noise*.04*exp(d*14)
            else:
                accents += sum(sin(tau*f*d) for f in (418,673,1019))*.046*exp(-d*13)
        elif kind=="thread" and 0<=d<.19:
            accents += (.112*treble+.056*sin(tau*676*d))*exp(-d*31)*min(1,d*820)

    fade=min(1,t*25,max(0,duration-t)*2.1)
    limited=tanh(1.26*(drive*(bass+kick+hats+clap+chord)+middle+accents))*.90*fade
    width=.018*treble*exp(-hat_time*84)*drive*fade
    samples.extend((round((limited+width)*32767),round((limited-width)*32767)))
if sys.byteorder!="little":
    samples.byteswap()
parser=ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path, default=root/"public/tonali/score.wav")
target=parser.parse_args().output
with TemporaryDirectory() as scratch:
    source=Path(scratch)/"raw.wav"
    with wave.open(str(source),"wb") as output:
        output.setparams((2,2,rate,0,"NONE","not compressed"))
        output.writeframes(samples.tobytes())

    command=["ffmpeg","-hide_banner","-nostdin","-y","-i",str(source)]
    settings="loudnorm=I=-16:TP=-1.7:LRA=7"
    measurement=subprocess.run(command+["-af",settings+":print_format=json","-f","null","-"],
                               check=True,capture_output=True,text=True).stderr
    measured,_=json.JSONDecoder().raw_decode(measurement[measurement.rfind("{"):])
    keys={"I":"input_i","LRA":"input_lra","TP":"input_tp","thresh":"input_thresh"}
    analysis="".join(f":measured_{key}={measured[field]}" for key,field in keys.items())
    analysis+=f":offset={measured['target_offset']}:linear=true"
    subprocess.run(command+["-v","error","-af",settings+analysis,"-ar","48000","-c:a","pcm_s16le",
                            str(target)],check=True)
