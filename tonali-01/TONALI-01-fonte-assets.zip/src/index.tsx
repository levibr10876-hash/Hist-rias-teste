import {Composition, registerRoot} from 'remotion'
import {formats} from './pro/engine'
import {Commercial} from './tonali/Commercial'
registerRoot(() => <Composition id="Tonali01" component={Commercial}
  {...formats.vertical} fps={60} durationInFrames={1200}/>)
