import {Composition, registerRoot} from 'remotion'
import {CrestPlate, GarmentPlate} from './Plate'
registerRoot(()=><>
  <Composition id="TonaliGarmentPlate" component={GarmentPlate} width={1728} height={1728} fps={60} durationInFrames={1}/>
  <Composition id="TonaliCrestPlate" component={CrestPlate} width={688} height={671} fps={60} durationInFrames={1}/>
</>)
