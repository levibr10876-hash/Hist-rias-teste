import {AbsoluteFill, Audio, Img, staticFile} from 'remotion'
import type {CSSProperties, ReactNode} from 'react'
import {Kinetic, useTime} from '../pro/engine'
import {smooth} from '../pro/timing'
import {productFocus, tonaliCamera} from './motion'

const black='#151412'
const paper='#f2eee6'
const milk='#f3efe6'
const red='#a52d2b'
const gold='#bd9a59'
const serif='"DejaVu Serif", Georgia, serif'
const sans='"DejaVu Sans", Arial, sans-serif'
const mono='"DejaVu Sans Mono", monospace'
const file=(name:string)=>staticFile(`tonali/${name}`)
const gate=(t:number,start:number,up:number,down:number,end:number)=>smooth(t,start,up)*(1-smooth(t,down,end))

function StageType({text,t,start,top,size=138,color,align='left',style}:{
  text:string;t:number;start:number;top:number;size?:number;color:string;align?:'left'|'center';style?:CSSProperties
}) {
  return <div style={{position:'absolute',left:76,right:76,top,textAlign:align,color,...style}}>
    <Kinetic mode="position-scale" text={text} t={t} start={start} duration={.49}
      style={{fontFamily:sans,fontWeight:900,fontSize:size,letterSpacing:'-.095em',lineHeight:1}}/>
  </div>
}

function Label({children,style}: {children:ReactNode;style?:CSSProperties}) {
  return <div style={{font:`700 21px ${mono}`,letterSpacing:3,...style}}>{children}</div>
}
function Ruler({grow,color}: {grow:number;color:string}) {
  return <svg width="100%" height="14" viewBox="0 0 930 14" preserveAspectRatio="none" style={{display:'block'}}>
    <line x1="0" x2={930*grow} y1="7" y2="7" stroke={color} strokeWidth="1.5"/>
    <circle r="4" cx={930*grow} cy="7" fill={color}/>
  </svg>
}
function Matte({amount,children}: {amount:number;children:ReactNode}) {
  if(amount<=0) return null
  if(amount>=1) return <AbsoluteFill>{children}</AbsoluteFill>
  const edge=-8+amount*126
  return <AbsoluteFill style={{clipPath:`polygon(-26% 0%, ${edge-15}% 0%, ${edge+7}% 100%, -26% 100%)`}}>
    {children}
  </AbsoluteFill>
}

// Asset slots use the original plates. The 1280px surface maintains consistent crop coordinates.
function OriginalPlate({style}: {style?:CSSProperties}) {
  return <Img src={file('moletom.webp')} draggable={false} style={{position:'absolute',left:0,top:0,width:1280,height:1280,objectFit:'contain',...style}}/>
}

export function Commercial() {
  const t=useTime()
  const pose=tonaliCamera(t)
  const gallery=smooth(t,2.66,3.30)
  const detail=smooth(t,6.49,7.14)
  const returnToPaper=smooth(t,12.08,12.92)
  const end=smooth(t,16.72,17.34)
  const front=1-end
  const first=1-smooth(t,2.38,2.92)
  const lightWord=gate(t,2.83,3.27,6.08,6.62)
  const macro=gate(t,7.10,7.62,8.55,8.99)
  const line=gate(t,9.00,9.47,11.81,12.25)
  const tag=gate(t,10.33,10.59,11.53,11.98)
  const identity=gate(t,12.55,13.08,16.34,16.93)
  const lowLight=.94+.06*smooth(t,0,1.4)
  const {anchorX,anchorY,sampleX,sampleY,zoom,roll}=pose

  return <AbsoluteFill style={{background:black,color:milk,overflow:'hidden',fontFamily:sans}}>
    <AbsoluteFill style={{background:'radial-gradient(ellipse at 62% 39%,#423c32 0%,#22201b 47%,#131211 79%)'}}/>
    <Matte amount={gallery}><AbsoluteFill style={{background:`linear-gradient(118deg,#ded8ce,${paper} 62%,#fcfaf3)`}}/></Matte>
    <Matte amount={detail}><AbsoluteFill style={{background:'radial-gradient(ellipse at 73% 55%,#393228,#1e1a17 48%,#161411 76%)'}}/></Matte>
    <Matte amount={returnToPaper}><AbsoluteFill style={{background:'linear-gradient(145deg,#e4ddd0,#f2ece1 65%,#e9dfcd)'}}/></Matte>
    <Matte amount={end}><AbsoluteFill style={{background:'linear-gradient(117deg,#f9f6ef,#e9e2d7)'}}/></Matte>

    <div style={{position:'absolute',inset:0,opacity:lightWord*.53}}>
      <div style={{position:'absolute',left:205,top:462,width:668,height:1006,border:'1px solid #81715b76',borderRadius:'50% 50% 43% 43%'}}/>
      <div style={{position:'absolute',left:537,top:345,width:1,height:1195,background:'#8c76504a'}}/>
    </div>

    <StageType text="PRESENÇA." t={t} start={-.35} top={287-34*smooth(t,.4,2.4)} size={146} color={milk} style={{opacity:first}}/>
    <StageType text="SE VESTE." t={t} start={2.88} top={269} size={148} color={black} style={{opacity:lightWord}}/>
    <div style={{position:'absolute',left:823,top:581,width:183,height:860,
      opacity:identity*.84,background:'linear-gradient(145deg,#992b2b,#723124 84%)',
      transformOrigin:'top',transform:`scaleY(${smooth(t,13.02,15.35)})`}}/>
    <div style={{position:'absolute',left:68,right:68,top:337,opacity:identity}}>
      <div style={{font:`italic 80px ${serif}`,color:red,letterSpacing:'-.085em'}}>
        <Kinetic text="Sua." t={t} start={12.44} mode="line"/>
      </div>
      <div style={{color:black,fontWeight:900,fontSize:130,letterSpacing:'-.084em',lineHeight:1}}>
        <Kinetic text="IDENTIDADE." t={t} start={12.67} mode="position-scale"/>
      </div>
    </div>

    <div style={{position:'absolute',left:anchorX-418,top:`${69+3*end}%`,width:836,height:148,
      borderRadius:'50%',opacity:(.28*lightWord+.25*identity+.24*end),
      transform:`scaleX(${.71+.11*end})`,background:'radial-gradient(ellipse,#3a3023,transparent 69%)'}}/>
    <div data-tonali-product style={{position:'absolute',left:anchorX,top:anchorY,width:1280,height:1280,
      transformOrigin:'0 0',transform:`rotate(${roll}deg) scale(${zoom})`,opacity:lowLight}}>
      <Img src={file('garment-plate.png')} draggable={false} style={{position:'absolute',
        left:-sampleX-80,top:-sampleY-80,width:1440,height:1440}}/>
    </div>

    <div style={{position:'absolute',inset:0,opacity:first}}>
      <Label style={{position:'absolute',left:77,top:155,color:'#d9c5ab'}}>TONALI</Label>
      <div style={{position:'absolute',left:76,right:76,top:206}}><Ruler grow={smooth(t,0,1.55)*.65} color={gold}/></div>
      <div style={{position:'absolute',left:77,top:1583,color:milk,font:`italic 73px ${serif}`,letterSpacing:'-.075em'}}>
        <Kinetic text="Não se explica." t={t} start={.95} mode="line" duration={.58}/>
      </div>
    </div>

    <div style={{position:'absolute',inset:0,opacity:lightWord}}>
      <Label style={{position:'absolute',left:78,top:162,color:red}}>TONALI / 01</Label>
      <div style={{position:'absolute',left:76,right:76,top:205}}><Ruler grow={smooth(t,2.96,5.72)} color="#74513b"/></div>
      <div style={{position:'absolute',left:80,top:1603,font:`italic 54px ${serif}`,color:black}}>
        <Kinetic text="Moletom preto." t={t} start={4.10} mode="opacity"/>
      </div>
      <div style={{position:'absolute',right:80,top:1608,width:60,height:8,background:red,transform:`scaleX(${smooth(t,4.6,5.45)})`}}/>
    </div>

    <div style={{position:'absolute',inset:0,opacity:macro}}>
      <Label style={{position:'absolute',left:76,top:157,color:gold}}>A MARCA NO PEITO</Label>
      <div style={{position:'absolute',left:76,right:76,top:208}}><Ruler grow={smooth(t,7.19,8.51)*.56} color={gold}/></div>
      <div style={{position:'absolute',left:78,top:334,font:`italic 78px ${serif}`,letterSpacing:'-.07em',color:milk}}>
        <Kinetic text="O símbolo." t={t} start={7.04} mode="line"/>
      </div>
    </div>

    <div style={{position:'absolute',inset:0,opacity:line}}>
      <Label style={{position:'absolute',left:76,top:157,color:gold}}>MANGA / DOURADO</Label>
      <div style={{position:'absolute',left:76,right:76,top:208}}><Ruler grow={smooth(t,8.91,10.6)*.68} color={gold}/></div>
      <div style={{position:'absolute',left:76,top:293,font:`italic 75px ${serif}`,letterSpacing:'-.073em',color:milk}}>
        <Kinetic text="A linha." t={t} start={8.96} mode="line"/>
      </div>
    </div>

    <div style={{position:'absolute',left:77,top:1268,width:372,opacity:tag,transform:`translateY(${34*(1-tag)}px)`}}>
      <div style={{height:244,border:'1px solid #bca582a0',overflow:'hidden',position:'relative',background:'#201c18'}}>
        <OriginalPlate style={{left:186-productFocus.tag[0]*3.18,top:120-productFocus.tag[1]*3.18,
          transform:'scale(3.18)',transformOrigin:'0 0'}}/>
      </div>
      <Label style={{marginTop:17,color:milk,fontSize:18,letterSpacing:2}}>ETIQUETA VERMELHA</Label>
    </div>

    <div style={{position:'absolute',inset:0,opacity:identity*front}}>
      <Label style={{position:'absolute',left:77,top:156,color:red}}>TONALI</Label>
      <div style={{position:'absolute',left:77,right:77,top:205}}><Ruler grow={smooth(t,12.7,14.5)} color={red}/></div>
      <div style={{position:'absolute',left:76,right:76,bottom:283,height:1,background:'#967a48a8'}}/>
    </div>

    <div style={{position:'absolute',inset:0,color:black,opacity:end}}>
      <div style={{position:'absolute',left:78,right:82,top:140}}><Ruler grow={smooth(t,16.92,17.85)} color={red}/></div>
      <div style={{position:'absolute',left:75,right:78,top:1469,borderTop:'1px solid #846c4d9c',paddingTop:21}}>
        <Kinetic text="TONALI" t={t} start={17.04} mode="position-scale" duration={.56}
          style={{fontSize:128,fontWeight:900,letterSpacing:'-.097em',lineHeight:.98}}/>
        <div style={{font:`italic 52px ${serif}`,letterSpacing:'-.054em',color:black,marginTop:24}}>
          <Kinetic text="Vista sua identidade." t={t} start={17.70} mode="line" duration={.53}/>
        </div>
      </div>
      <Img src={file('crest-plate.png')} draggable={false} style={{position:'absolute',
        right:83,top:1493,width:240.8,height:234.85}}/>
    </div>
    <Audio src={file('score.wav')}/>
  </AbsoluteFill>
}
