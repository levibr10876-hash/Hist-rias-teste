import {type ReactNode, type CSSProperties} from 'react'
import {smooth} from './timing'
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion'

export const formats = {
  vertical: {width: 1080, height: 1920},
  wide: {width: 1920, height: 1080},
  square: {width: 1080, height: 1080},
}
export type Format = keyof typeof formats
export const defaultFps = 60
export const ease = Easing.bezier(.25,.8,.28,1)
export const snap = Easing.bezier(.74,0,.2,1)
export function phase(t: number, start: number, end: number, curve = ease) {
  return interpolate(t,[start,end],[0,1],{easing:curve,extrapolateLeft:'clamp',extrapolateRight:'clamp'})
}
export const mix = (from: number, to: number, p: number) => from+(to-from)*p
export const pulse = (t: number, at: number, attack: number, release: number) =>
  phase(t,at-attack,at) * (1-phase(t,at,at+release))
export const useTime = () => useCurrentFrame()/useVideoConfig().fps
export function useLanding(second: number) {
  const frame=useCurrentFrame()
  const {fps}=useVideoConfig()
  return spring({fps,frame:Math.max(0,frame-Math.round(second*fps)),config:{mass:.8,damping:19,stiffness:160}})
}
export type Point = readonly [number,number]
export function morph(from: readonly Point[], to: readonly Point[], progress: number) {
  if (from.length !== to.length || from.length < 3) throw new Error('Contornos devem ter pontos correspondentes.')
  return from.map(([x,y],i) => `${mix(x,to[i][0],progress)},${mix(y,to[i][1],progress)}`).join(' ')
}
export function trajectory(p: number, a: Point, b: Point, c: Point): Point {
  return [mix(mix(a[0],b[0],p),mix(b[0],c[0],p),p),mix(mix(a[1],b[1],p),mix(b[1],c[1],p),p)]
}
export type EntryMode = 'word'|'line'|'block'|'mask'|'stagger-word'|'stagger-character'|'opacity'|'position-scale'

export function Kinetic({text,t,start,mode='line',style,accent,unitGap=.07,duration=.42}: {
  text:string;t:number;start:number;mode?:EntryMode;style?:CSSProperties;accent?:string;unitGap?:number;duration?:number
}) {
  const units = mode === 'stagger-character'
    ? Array.from(new Intl.Segmenter('pt', {granularity:'grapheme'}).segment(text), part => part.segment)
    : mode === 'stagger-word' ? text.split(/(\s+)/) : [text]
  let spokenIndex=0
  return <div aria-label={text} style={{whiteSpace:'pre',...style}}>
    {units.map((unit,index) => {
      if (/^\s+$/.test(unit)&&units.length>1) return <span aria-hidden key={index}>{unit}</span>
      const delay=start+spokenIndex++*unitGap
      const p=smooth(t,delay,delay+duration)
      const translate=mode==='opacity'||mode==='mask'?0:(1-p)*.24
      const scale=mode==='position-scale'?1-.045*(1-p):1
      const clip=mode==='mask'&&p<1?`inset(${-0.20}em ${(1-p)*103}% ${-0.20}em -0.20em)`:undefined
      return <span aria-hidden key={index} data-motion-type={mode} data-motion-done={p===1?'true':'false'}
        style={{display:'inline-block',verticalAlign:'top',opacity:mode==='mask'?Number(p>0):p,clipPath:clip,
          transform: p===1?undefined:`translateY(${translate}em) scale(${scale})`,transformOrigin:'left center',
          paddingBlock: mode==='mask'?'.18em':undefined,marginBlock:mode==='mask'?'-.18em':undefined}}>
        {mode==='block'&&accent ? text.split('\n').map((line,i)=><span key={i} style={{display:'block',color:i===0?undefined:accent}}>{line}</span>) : unit}
      </span>
    })}
  </div>
}
export function MotionTrail({time,fps,children}: {time:number;fps:number;children:(t:number)=>ReactNode}) {
  return <>{[3,2,1,0].map(i=><div key={i} style={{position:'absolute',inset:0,opacity:i===0?1:(4-i)*.10}}>
    {children(Math.max(0,time-i/fps))}
  </div>)}</>
}
export function CameraPlane({x=0,y=0,z=0,tilt=0,yaw=0,roll=0,focus=0,children}: {
  x?:number;y?:number;z?:number;tilt?:number;yaw?:number;roll?:number;focus?:number;children:ReactNode
}) {
  return <div style={{position:'absolute',inset:0,perspective:1400}}>
    <div style={{position:'absolute',inset:0,transformStyle:'preserve-3d',
      transform:`translate3d(${x}px,${y}px,${z}px) rotateX(${tilt}deg) rotateY(${yaw}deg) rotateZ(${roll}deg)`,
      filter:focus ? `blur(${focus}px)` : undefined}}>{children}</div>
  </div>
}
