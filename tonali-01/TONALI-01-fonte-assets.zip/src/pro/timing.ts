const clamp = (p: number) => Math.max(0, Math.min(1, p))

export function smooth(time: number, start: number, end: number) {
  const p = clamp((time - start) / (end - start))
  return p ** 3 * (10 + p * (-15 + 6 * p))
}

type Timing =
  | {mode: 'simultaneous'; start: number}
  | {mode: 'stagger'; start: number; gap: number}
  | {mode: 'sequential'; start: number; gap?: number}
  | {mode: 'overlap'; start: number; overlap: number}
  | {mode: 'sound'; cueSeconds: number; offset?: number; gap?: number}

export function groupFrames(timing: Timing, count: number, duration: number, fps: number) {
  if (!Number.isInteger(duration) || duration < 1 || !Number.isInteger(count) || count < 1 || !(fps > 0)) {
    throw new Error('Grupo temporal inválido.')
  }
  if (timing.mode === 'overlap' && !(timing.overlap > 0 && timing.overlap < duration)) {
    throw new Error('A sobreposição deve caber na duração da entrada.')
  }
  const first = timing.mode === 'sound' ? Math.round(timing.cueSeconds * fps) + (timing.offset ?? 0) : timing.start
  const step = timing.mode === 'simultaneous' ? 0 :
    timing.mode === 'sequential' ? duration + (timing.gap ?? 0) :
    timing.mode === 'overlap' ? duration - timing.overlap : timing.gap ?? 0
  if (!Number.isInteger(first) || !Number.isInteger(step) || step < 0) throw new Error('Use quadros inteiros no grupo.')
  return Array.from({length: count}, (_, i) => first + i * step)
}

// Cubic Hermite with bounded monotone tangents. One pose/velocity on either side of a knot.
export function motionTrack(time: number, keys: readonly (readonly [number, number])[]) {
  if (time <= keys[0][0]) return keys[0][1]
  const last = keys.length - 1
  if (time >= keys[last][0]) return keys[last][1]
  const i = keys.findIndex(([t]) => t > time) - 1
  const [a,x] = keys[i], [b,y] = keys[i+1]
  const slope = (j: number) => (keys[j+1][1] - keys[j][1]) / (keys[j+1][0] - keys[j][0])
  const tangent = (j: number) => {
    if (j === 0 || j === last) return 0
    const left = slope(j-1), right = slope(j)
    return left * right <= 0 ? 0 : 2*left*right/(left+right)
  }
  const p = (time-a)/(b-a)
  const p2 = p*p, p3 = p2*p
  return (2*p3-3*p2+1)*x+(p3-2*p2+p)*(b-a)*tangent(i)+(-2*p3+3*p2)*y+(p3-p2)*(b-a)*tangent(i+1)
}
