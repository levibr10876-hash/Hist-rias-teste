# TONALI 01 · fonte e assets

Composição vertical nativa de 20 s em Remotion. Os WebP são os bytes entregues
no ZIP de referência, com extensão corrigida. O recorte do moletom é uma
máscara de composição e o brasão é exibido a partir do arquivo original.
A trilha instrumental e os efeitos foram sintetizados para o projeto.

No Motion Studio AI existente, copie src/tonali e public/tonali preservando
as pastas. O ponto de entrada nesta cópia também permite rodar separadamente
com Node 22+, as dependências do lockfile, DejaVu Sans, DejaVu Serif e Chromium.
A trilha já está incluída. Para sintetizá-la novamente, use FFmpeg e rode
`python3 scripts/tonali-score.py`.

```sh
npm ci
npm run typecheck
npx remotion render src/index.tsx Tonali01 TONALI-01.mp4 --color-space=bt709 --pixel-format=yuv420p --crf=17
```

Caso utilize Chromium de sistema, passe `--browser-executable`. O master
fornecido usa Chromium 156 no ambiente de operação.

As duas placas PNG transparentes pré-compõem o contorno e a sombra do
moletom e a separação do brasão do papel. Para refazer as placas:

```sh
npx remotion still src/tonali/plates-entry.tsx TonaliGarmentPlate public/tonali/garment-plate.png
npx remotion still src/tonali/plates-entry.tsx TonaliCrestPlate public/tonali/crest-plate.png
```
